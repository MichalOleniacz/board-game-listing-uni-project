package org.michaloleniacz.project.category.dto;

public record CategoryDto (
        int id,
        String name
)
{ }
