package org.michaloleniacz.project.game.dto;

public record SearchGameRequestDto(
    String query
) { }
