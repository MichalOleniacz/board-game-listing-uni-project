package org.michaloleniacz.project.preference.dto;

public record PreferenceDto (
        int id,
        String name
) {}
