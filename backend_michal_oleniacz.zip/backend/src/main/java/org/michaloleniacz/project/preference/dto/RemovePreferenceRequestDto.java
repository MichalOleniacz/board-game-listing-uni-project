package org.michaloleniacz.project.preference.dto;

public record RemovePreferenceRequestDto (
        int preferenceId
) { }
