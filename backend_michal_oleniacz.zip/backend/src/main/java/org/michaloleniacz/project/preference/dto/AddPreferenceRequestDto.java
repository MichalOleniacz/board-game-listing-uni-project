package org.michaloleniacz.project.preference.dto;

public record AddPreferenceRequestDto (
        int preferenceId
) { }
