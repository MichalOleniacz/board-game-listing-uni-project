package org.michaloleniacz.project.testEndpoint;

public record TestRequest (
        String test,
        int testNumber
) {}
