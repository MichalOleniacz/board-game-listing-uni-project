package org.michaloleniacz.project.user.dto;

public record UserDetailsDto(
        String firstName,
        String lastName,
        String city
) {
}
