package org.michaloleniacz.project.user.dto;

public record PromoteUserToAdminRequestDto (
  String email
) { }
