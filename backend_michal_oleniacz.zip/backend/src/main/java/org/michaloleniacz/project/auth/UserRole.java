package org.michaloleniacz.project.auth;

public enum UserRole {
    USER,
    ADMIN,
}
